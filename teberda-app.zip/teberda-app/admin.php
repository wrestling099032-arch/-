<?php
/**
 * Точка входа в админку - отдает admin.html
 */
$file = __DIR__ . '/admin.html';
if (file_exists($file)) {
    readfile($file);
} else {
    http_response_code(404);
    echo 'admin.html not found';
}
