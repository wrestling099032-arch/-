<?php
$config = require __DIR__ . '/config.php';

define('DATA_DIR', __DIR__ . '/../data');
define('UPLOAD_DIR', __DIR__ . '/../images');

if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

function appConfig(): array {
    global $config;
    return is_array($config) ? $config : [];
}

function loadJsonFile(string $file, $default = []) {
    $path = DATA_DIR . '/' . $file;
    if (!file_exists($path)) {
        return $default;
    }
    $data = json_decode(file_get_contents($path), true);
    return $data === null ? $default : $data;
}

function saveJsonFile(string $file, $data): bool {
    $path = DATA_DIR . '/' . $file;
    return file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) !== false;
}

function startAdminSession(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function isAdminAuthenticated(): bool {
    startAdminSession();
    return !empty($_SESSION['td_admin_ok']);
}

function requireAdminAuth(): void {
    if (!isAdminAuthenticated()) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

function currentBaseUrl(): string {
    $cfg = appConfig();
    if (!empty($cfg['site_base_url'])) {
        return rtrim($cfg['site_base_url'], '/');
    }

    $host = $_SERVER['HTTP_HOST'] ?? '';
    if (!$host) {
        return '';
    }

    $scheme = 'http';
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
        $scheme = explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0];
    } elseif (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        $scheme = 'https';
    }

    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $basePath = rtrim(str_replace('\\', '/', dirname(dirname($script))), '/');

    return $scheme . '://' . $host . ($basePath ? $basePath : '');
}

function absoluteUrl(string $relative): string {
    if (!$relative) {
        return '';
    }
    if (preg_match('~^https?://~i', $relative)) {
        return $relative;
    }
    $base = currentBaseUrl();
    if (!$base) {
        return $relative;
    }
    return $base . '/' . ltrim($relative, '/');
}

function telegramRequest(string $method, array $params): ?array {
    $cfg = appConfig();
    $token = trim((string)($cfg['telegram_bot_token'] ?? ''));
    if ($token === '') {
        return null;
    }

    $url = 'https://api.telegram.org/bot' . $token . '/' . $method;
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query($params),
            'timeout' => 10,
        ],
    ];

    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);
    if ($result === false) {
        return null;
    }

    $json = json_decode($result, true);
    return is_array($json) ? $json : null;
}

function notifyTelegramNewRequest(array $request): bool {
    $cfg = appConfig();
    $chatId = trim((string)($cfg['telegram_chat_id'] ?? ''));
    $token = trim((string)($cfg['telegram_bot_token'] ?? ''));
    if ($token === '' || $chatId === '') {
        return false;
    }

    $contacts = array_filter([
        !empty($request['phone']) ? '📞 ' . $request['phone'] : '',
        !empty($request['tg']) ? '✈️ ' . $request['tg'] : '',
        !empty($request['wa']) ? '🟢 ' . $request['wa'] : '',
        !empty($request['insta']) ? '📸 ' . $request['insta'] : '',
        !empty($request['vk']) ? '🔵 ' . $request['vk'] : '',
        !empty($request['site']) ? '🌐 ' . $request['site'] : '',
    ]);

    $adminUrl = absoluteUrl('admin.php');
    $receiptUrl = !empty($request['checkPhoto']) ? absoluteUrl($request['checkPhoto']) : '';

    $lines = [
        '🆕 <b>Новая заявка на услугу</b>',
        '',
        '<b>Название:</b> ' . htmlspecialchars((string)($request['name'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        '<b>Город:</b> ' . htmlspecialchars((string)($request['city'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        '<b>Категория:</b> ' . htmlspecialchars((string)($request['categoryId'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        !empty($request['price']) ? '<b>Цена:</b> ' . htmlspecialchars((string)$request['price'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') : '',
        !empty($request['check']) ? '<b>Перевод:</b> ' . htmlspecialchars((string)$request['check'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') : '',
        !empty($request['desc']) ? '<b>Описание:</b> ' . htmlspecialchars((string)$request['desc'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') : '',
        $contacts ? '<b>Контакты:</b> ' . htmlspecialchars(implode(' | ', $contacts), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') : '',
        $adminUrl ? '<a href="' . htmlspecialchars($adminUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '">Открыть админку</a>' : '',
    ];

    $text = implode("\n", array_filter($lines, static fn($v) => $v !== ''));

    if ($receiptUrl) {
        $response = telegramRequest('sendPhoto', [
            'chat_id' => $chatId,
            'photo' => $receiptUrl,
            'caption' => mb_substr(strip_tags(str_replace('<br>', "\n", $text)), 0, 1000),
        ]);
        if (!empty($response['ok'])) {
            return true;
        }
    }

    $response = telegramRequest('sendMessage', [
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => 'true',
    ]);

    return !empty($response['ok']);
}
