<?php
return [
    // Обязательно поменяйте пароль перед продом.
    // После смены пароля: зайдите в admin.php
    'admin_password' => 'CHANGE_ME_ADMIN_2026',

    // Telegram уведомления о новых заявках
    // Пример: 1234567890:AA...
    'telegram_bot_token' => '',

    // Chat ID канала/группы/личного чата
    // Пример: -1001234567890
    'telegram_chat_id' => '',

    // Можно оставить пустым — URL соберётся автоматически.
    // Если сервер за прокси/CDN и ссылки в Telegram ломаются, укажите вручную:
    // 'https://example.com/project'
    'site_base_url' => '',

    'transfer_phone' => '+79298594699',
];
